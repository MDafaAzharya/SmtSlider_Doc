<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>
    <?php
    global $wpdb;
    $id = $_GET['id'];
    $table_smt_img = $wpdb->prefix . 'smt_img';
    $data_images = $wpdb->get_results("SELECT * FROM $table_smt_img WHERE id_slider = $id ");
    $table_smt_css = $wpdb->prefix . 'smt_style';
    $data = $wpdb->get_row("SELECT * FROM $table_smt_css WHERE id_slider = $id ");
    $css_data = json_decode($data->style_data, true);
    if (!empty($data_images)) {
       ?>
    <div class="sec container-fluid bg-container">
        <div class="container">
            <div class="row">
                <div class="col-md-1 col-12 my-auto">
                    <div class="indicator-dots">
                        <?php foreach ($data_images as $index => $data): ?>
                            <div class="dot-wrapper" onclick="showSlide(<?= $index ?>)">
                                <span class="dot <?= $index === 0 ? 'active' : '' ?>"><span class="dot-number"><?= $index + 1 ?></span></span>
                            </div>
                            <div class="dot-connector"></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                    <div class="col-md-5 text-slider my-auto" style="font-family:Verdana, Geneva, Tahoma, sans-serif;">
                        <div class="title_slide mt-5 pt-3 pt-md-0" id="preview_title_<?= $index + 1 ?>"><<?php echo $css_data['title_size']; ?>> Judul Slider 1 </<?php echo $css_data['title_size']; ?>></div>
                        <div class="desc_slide" id="preview_desc_<?= $index + 1 ?>"><p class="my-md-4" class="desc_slide"> Lorem ipsum, atau ringkasnya lipsum, adalah teks standar yang ditempatkan 
                            untuk mendemostrasikan elemen grafis atau presentasi visual seperti font, tipografi, dan tata letak.</p>
                                <button class="btn-custom"> Explore </button>
                        </div>
                    </div>
                    <div class="col-md-6 my-md-5 pt-md-5">
                        <div class="slider-wrap my-auto">
                            <div class="slider-pannel col-md-12">
                            <?php foreach ($data_images as $index => $data): ?>
                                <div class="slide col-md-4 <?= $index === 0 ? 'active' : '' ?>" onclick="showSlide(<?= $index ?>)" data-background="<?= wp_get_attachment_url($data->bg_img) ?>" data-text="<?= $data->button_link ?>">
                                    <img class="inner" src="<?= wp_get_attachment_url($data->img) ?>">
                                    <div class="slide-text">
                                        <h3><?= $data->title ?></h3>
                                        <p><?= $data->desc ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="slider-controls">
                        <button class="carousel-control-prev ms-md-3" onclick="moveSlide('prev')">
                            <i class="fa-solid fa-arrow-left"></i>
                        </button>
                        <button class="carousel-control-next" onclick="moveSlide('next')">
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
            </div>
        </div>
    </div>
    <?php
    }else{
    ?>
    <!-- Tes -->
    <div class="sec container-fluid bg-container">
        <div class="container">
            <div class="row">
                <div class="col-md-1 my-auto">
                    <div class="indicator-dots">
                        <div class="dot-wrapper" onclick="showSlide(0)">
                            <span class="dot"><span class="dot-number">1</span></span>
                        </div>
                        <div class="dot-wrapper" onclick="showSlide(1)">
                            <span class="dot"><span class="dot-number">2</span></span>
                        </div>
                        <div class="dot-connector"></div>
                    </div>
                    
                </div>
                <?php
                global $wpdb;
                $table_smt_css = $wpdb->prefix . 'smt_style';
                $data = $wpdb->get_row("SELECT * FROM $table_smt_css WHERE id_slider = $id ");
                $css_data = json_decode($data->style_data, true);{
                ?>
                <div class="col-md-5 text-slider my-auto" style="font-family:Verdana, Geneva, Tahoma, sans-serif;">
                    <div class="title_slide mt-5 pt-3 pt-md-0"><<?php echo $css_data['title_size']; ?>> Judul Slider 1 </<?php echo $css_data['title_size']; ?>></div>
                    <div class="desc_slide"><p class="my-md-4" class="desc_slide"> Lorem ipsum, atau ringkasnya lipsum, adalah teks standar yang ditempatkan 
                        untuk mendemostrasikan elemen grafis atau presentasi visual seperti font, tipografi, dan tata letak.</p>
                        <button class="btn-custom"> Explore </button>
                    </div>
                </div>
                <?php
                }
                ?>
                <div class="col-md-6 my-md-5 pt-md-5">
                    <div class="slider-wrap my-auto">
                        <div class="slider-pannel col-md-12">
                            <!-- Slide 1 -->
                            <div class="slide col-md-4 active" onclick="showSlide(0)" data-background="https://www.pinhome.id/info-area/wp-content/uploads/2022/07/Gunung-Prau-1.jpg" data-text="Explore 1">
                                <img class="inner" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVEhgSFRYYGRgYGBgYGhgaGhgYGBgYGBgaGhoYGBgcIS4lHB4rHxgaJjgnKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QGhISHjQhISE0NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0MTQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ2NP/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAABAgADBAUGB//EAD4QAAEDAQUFBgQEBQMFAQAAAAEAAhEhAxIxQVEEImGR8AUTMnGBoUKxwdEGUpLhFGJygvEVQ6Izc7LC4iP/xAAZAQEBAQEBAQAAAAAAAAAAAAABAAIDBAX/xAAhEQEBAQACAgMBAQEBAAAAAAAAARECEiExAxNRQaEyYf/aAAwDAQACEQMRAD8A9kxqcNUa1NC9rgF1S6imAUiXEQ1WBqMI1YquoXVahCtOEDU4UhSFLRUURQRARuqBMEIIUupkUIl1G6mUUiwopKEqODCBCl5CVFIUhCUJUDJVJUUkQlGFLqiWVCmuqXVIsKQnAUKNRIURUWexwqigcgSu7kKISoyhGCJSypKiKiEqIWijCARClBhGFEJUTIyklCUYlkoEpJQlC05elvISopCjCCkqMMoklQKJoRhABMAoBdRhSFFIUCUCUC5SQlC8gXJHOWSe8kdaJC5ISmo/eHRRVXlEdTpw5G8kuoyu2OOmvI3lUXqByMWrC9S8q5RCcWrA5MHKoJgUYtWhyIKqBRvKMqyUbypvFO1B00qKAJgFEAonhRZRQmSlyUvUliUpDaJO9Vi1YSoCqTaqd6rFrSHJg9ZhaIG0RhaS9IXrMXlAuKsTSXpC9Zy4pSSktBekLlRfQNopLiUhcqzaJC9GBbeUWfvFEp0bspTZFMx/FWC1XRy2KDZFI6yK1m28lWbRXlay92UQCri7igStAgcUwekc5VuerFrSLRTvlkL0O8R1XZs71TvAsXeKd6rqezb3h1RG0kYrD3il9HU9m/8Aikp2jisXqiG8VdYtanWvFVm04qq6pc4oyLTG1QvoCy4pm2KvBFpVjQo2y4p7oGazaYlEC9QualLwgldaJHPKjnhI60WsGgXFAkpXWqR1qqxaeSlJVbrRISUYtXF6QvVUFAgrS1ZeUVcKIwa7N1AgpZKl5dscdQkoX0wcpeUtL3ineIlKVYtElIUZUUdIWpCxaGMbmU9xqOyxiLELq2FgSlg4K7HGNMCtJswh3KLYpFIPFMAre64j3+ylziPdGtYVrE1wKBnEKGzOo5rNpgyAgbRKbJ2o5pDZuV4JzalIbRKbN2iBY7RXhGNolLkIKFxxyShJSko907QoGwf+U8ijwgLkpenOzv0S90cyP1N+6fAIXpTaJiBm5vP7IQ3Ue6MWlNokdaqwMnAe/wC6YbK7Jo5hPiJn71Raf4N+jebVEduKx1ixI5i0XwhfC32rleLNCNw6K8vCQkJ7DqqLDoUO5doVYSNEDd0V2PUvcO6IU7o8OYUvDRLfGnsjaupu7PDmELh4cwhfGg5BQ2yNpyAQdfcIevyUNqgbdW05EqpeQNqub2v24zZ2y6HPI3WDE8T+VvHlKLacdC2t2saXvcGtGLnEBo8yaLl2/wCJtlYYNqCcd1r3j9TQR6SvB9qdp2u0vv2jpA8LBIYz+luvHHisQas9mse/f+M9mBiLR3EMbH/J4PstWyfiXZrRwY18OOAc0sngHERPCZK+bFqVzUdi+wXjoeSNeK8H2F+KHWYFnbFz2CgfJL2DQ/maOY40C9lYbSy0aHscHNOBBkUxHA8FqeRfDTcGnuPuiI0j9P3WYpCArBrYXjU8wPkUDaD8x/UfusUBSieoazaN/MeZVD3A58ySqqKUViQgajkVL+hb+lSULyUcbQ783IJv4p35ncgqryl5COdof+Z3IIi2fq/5fRV3yheVhWd8/V/P/wCVFXfKiuqbztLuCY7UdAs8pS5ac17dqdnX2Vn8SFiLkpcnwG42oSm0WG+h3x1VibS9KXrBabVdEuIAGZoFhd29ZzEk8Q0x71Tg13DaJTaLze0fiAzDGgjV01/tB+vosdr2vbPEXrozuC6f1TI9IUXry9VHa2AkF7ARiC9oI860XhNoeJlxvHCSZPMrOTP2WLyjU42vS9qfiaJZYCThfIkf2DPzNKYFeWfecS5xLnGpcTJJ4k4q5tmi4LFutyYz93goLNarihZQLJZ7iQ2a1hsJTZqTGWLZ2V2m/Z33mVafEw+F32I1/wAJe7Vb2I9LXu+ze2LO3G6YfFWHxDUj8w4j1hbC5fNbhBBEitCKEHzGBXd7J/EJbFnbEuGT8XD+sfEOOPmunHlL7Z5S/wAeslKXKmztmuaHNIIIkEYGVC9dOrOrbyl5Z3WkKp21AaJ6rs2SgXLEdtGhPkp/HN4q60do2XlLy5z+0Rk0nzMfdH/Um6O9vurrT2joXkL6xf6iyM/KFW7tJoyJV1q7OhfUXM/1T+X/AJfsonpVseifQS6lMTQcyVi2jtGyZ4nt8hLj6hoMLx5bP7/dEMXLqa9C7t6ynB58mtg/8lltfxBXcZTUuryGHNcfu0blVqJ0n9tvyY0fqP2WR/aNq74yPKG/Kqpe2El1IqWtq55l7i4jX6aKsBOYSOeOKLz4wTjahIzog60OVOsggXE/fmgGarly+TXScShvPrkiBoE4b18krh116rHY4gQaKoF1Y66xTg5p1CUQkBnyTHrryRqRyRyeJQcyfPqqtJXBVv8An7K1unVElqyMcOqqSpzRhFUj2aV5eoVgGR/x5JHs6pzTEt2ban2ZljiK1biHUxI6812tj7YY+A/cdr8B9fh9ea89OvX3RIHlocvVb487xHLjK9g5iQhec2TtB9nQVb+V1QP6cx1RdOy7ZY7xAt9xzH2Xbj8krjeFjY4KtxVwtARNCDmIIPqECRP+V11nFBKQq8tSvgYkDzgK04zkIQme9n5hzn5Kl20t4nyH3VoPCiHfN/MOYUUVYe3UKG0Go4rHFYn5ouNI0yn6QvHflrv1jUbfQdQqn7QdPcfRVuacagGtc8pB8wm7t0SGmKwYpTGD6ifNY+ymcYY2p6hVDGazxUc0+EisAxTAiQfVplWOsj6+9TApiamKcAud+ST3Wpx/ISNOGR+aUHP956lXt2V1IiSWtoSBJmBOAwJg/lUbZSAaXXOLZqd6hk0oIPthms/Zx/Wpxv4qDh1lkeuCN7iOPHSisDLMjxj4muMyQ4TdrpPyyQYG3jDCRLg0OMSDujw+hBBBnSFX5OK6cizQekfsq3HGRgc8eKj9tjdm6RABDYIi7QzgQWAzqFaXgmQAa/ERUGIkiK8eOCO+H67+qGuA3jiTQSJ1jjQJgwmrhlMDCNTrktE7u4IugmgjOtTXHjxhZG7U6d4iMKzJ5Iny8vw/VFwaYw9x9UjrQDEj3jEjEBKwMf4QLxI0qcKzQp27Mb7mPgtYCXCbsgYGXTu+EzAxyKu3KrpCttaUBjl++KuaZw61Wd9qwsLBu794SGmGgEQXRMmkxQ8ICTZ3mSG10nOZgxrhyROXKXz6F4xe6lf31TEjqqrZaSK414VH+EWkGAf35LvLvlzswjrPRVsPJauXWUKt9notSjFRaDh1nX3VZEGqseM+uCJqOHn8lpYrB5afZBp1TRBnEcfkULs/bI5x5qiPYWj2G8wxwgEH0MgreztZ3xNE6gAD9IXNLSI+fASmDluc7BeMroO2pz63uMCiqcFTc0RDyuvHm53isUhKHFS8VrvB1qQihe4Iq7Qda2bHsN+zfaX7twAxBN+ZwqNBqVn2ljW7u9evNAkRec4E3Q0SZFaaDGq2bM15Y6+CwCJaTvGGOGkTGWPqmdaNdaeAAzO8GumpALRkdBo31XxeXycrd3H0JwmJ2jYOdZ7PDXC8wgYzi0icx4lnZtMA2RAEh7YLquvXagwR4mtJwgamiLdqmRfAawlhwFRUtE6AiRksbGtfay2XRW8Bu3nTO8CYxGireXKZfEjU4T3D7b2kWRZiZFm0SCIN2N6NJaBWtOCqZYvIlzZLhIlpdWaGcMCMsvUdOy2A0gNk45ukcSBznkr+5aBF0aazgRHss5I3ODjNtbZom4TBD6AOJc2YcBUzU6kThmL7Oxe6HOY8Fx8QbEiajw5TXCM9Vuew4BxGegr5RkPmo5j8oiKSAScKCeHFVnGzx4XWsFpZMaILnS2AYM1nM1MiRQz4aTkrrBgdBeQQBO4RukSJqJMAY1wT7dYPLXbra1BIumKAgOBLSJmPMrq9kdjh9mHvBvG9dAIa3dkDw1OdTQAjPCnHlf6xfDzlq1rqi7jOUnGRMV8vtV7O0DeGQOA1Ij7Lsdt9lMsWi3LHBjiA5s3g2TGI8J1k6DNcSz7SZeLGscWuEbxa/eEEYEYUxrotW31g2NL3A4afy1A4zQ+c+yqbspe6M8SaClOOOHnISs2pj2uLWgXYqwEjAUcBnjvZ3UDaubWpJwIdukTWRmaDGEy+VW/Y9mALHtBzIOtKgCcuGqotyLWzc9gbLXC8c3ABrQBpG8fIcFtsmD+G7wG7duAEULSWvw4m4fUhc3ZQ+68tZeBlpuiskflBmRSDEZLd5YmQskcYnka/IrfZbPdIeSIoYkGA7widb0NJjHgU9nYS1woHiRBEGYGMjr0Tv2hga4SA65dZNYuiAAMnbxM8MlaMYnWxdIikk8ZrPkazoULO0BqDzx6lViSKCOGfp6fTig9oc29oYdETJNfTNXHnfTneMrU60TB8iccT6dTyWABzRLXTwOPDKoqFay2Mw5sHTrGYPJdZz/R1xqoesfv+ypAinnHHXrzSXhkdcZGJ1+qsaTmM+C6ceU/jGVAM+CI8s+frzxSlvp5/slJI9fLBa0L2spj19kLvpwVYtOMdUnmnbaJKEFO06qBw6xRaQmUYYMGqcNSXlY1OjAujqFFdTqEFd6eo2+2wIYR5EElxpApj5D6rLYWxcQ66NIaCwRJpIOCvZ2cDiXH0AvDDemZFTIwg1WwWLRENaBhIaBGcUw8uC+VnGX9e7rb7UjYmuaN3dFBJDgCTQS4G9hOfzWxjgIBOp6iBiMkAYqMcBgTWlKceB0S2pgwYJ4Ga+iN8Y6TjIV1o7DI1w4YxkmvAY10OGlIGPskm8CaCMRhyBxSsfBBBPmJkZUjOpUWhlq0w2gpW+4BpIMmKU9zVabVjQyWuBcaGl0amSa9ZLnkkkudU5zUzOJ5HilDoETHIYk5Z51RqxpaxtMyPvkBXMe6V+1PAaJoIEXRIy+KfdUB+cGk8cMSKeil+RlqKEmk0LeWNE8arGuy2pwDmvcHAjgIMxByIz4ED05dv2cx8iQwaBsswkPihDgZwJx1krTZWZm6GQD+a6JbQgS0FxBHv5ys9pY2kbrmkEmpaXOLiSAAAazdIoJ3vKOku+NcuUn44lh2dbWVpUC4SZc0ktIzaT/cBEHGq7zGWW7LWu3KyQbpJgiW0DQQKkk6eJYxbuZRzmkRiHG8CQcpMb0gjEAZyrDtrXtBoRe3rkyWtu3XToIpjjmsfNx5WSz/HPxGg2Fk4OF5wYHXi0BpYTkCbwI3ZqZiTUp7MWl4m+RvC4Qb18wXFjswLgAnIuJ4LOzbGuc8ljLpui+CXtEExLRIwYJ1ummJWfZ9re5jHucXAh0PNGXpIq0jGoBAJ8Lo48rx52ef9Gt5s2ueHsfL4rUgEtrQA1wFa6+ebb9hJJgACKE7oeWi8I/mF6MvDRaNqtgTIdBgkPgBzmyYaCWwSQ4gA0dJrWhO0EuNm6aF3iIG7kWioJgDnqjj8nLjP/DZK4rHUGBpjPWYCjnES6JBADgP7ag9YLZa7NLi+t5xc4xIJ3zJAPigRPEnJV2jCA4Ab28NIoZAHr6RlMr0cbL6ZwH2FyLpkeKoqajMZVw81l2ppa6boiDgcJwkaRWfcmqewD4EO+KcTEEE1+6FjbYh8tMkVihwxwiq6TZP0K2PBqYIwnn7qMJbhyyPlxorbXZYAu1rQQAIqMPmqQJ1nKaGh60zSF7beg9oTseDGqytb/j0xCdjm5Y/WFqcrB1XgA5DliEzGieusENo2d7GB8ETBImtYAMeo9lQLWTX3ivlrit/YLxxre8BKbcdQsb3nWOeCXvD1+yZzWV0mWgK02cLmWFq0xWOBotjDC6ShqUVV46qK1OgxwzBg5iKZTBFaTSlcwoX46HjBxyVV4T5/bHjX5qGKY8edY9COa+fj3rbR96JrAguxmpilaRlXBVvdUjODNQ4Tr8lUXSaCaxzwn0yQa8AScAXeEEzTGpqPamaMWrWEDCDrQf5iiYuz9pmlfp9FSAaiKekUmuhw9UWmTIIrOhEZ0yKKosuGN0GYJNCYAzNKCuJ1QLZPrlE1kTB+X7JWPkhpcBzyjGmKjJxMxNdaiQNJgEqJ3NqQDIEN3hBNInONPTJM2KkuaRGdRMQD5gmcNcpSOfMwAOB45kz1RGzszWc4AJykYxStccKI1YS2nFzoJr4ml2VZI8RP01pU3aHD+bEOIc6k5OiQ0EjHGWmlKG0socImrxnIxgkIu2do1JA8RF06glowXSWMWXWE7S17gHtwGOZAJgOkVNYnHgqmbMcWPkXpuk1kGrQQ7Q+Ij1xW99uLxIqQRnBvAtgxjdktE+XBaDbh91j7oug3XQIExu0EkTEZaYwty1iyPNtsTZuu2jaRSoILjALb7XSJGIn7pi9032SPHcMuMhpguGZF4xHHTH0Vo1jrrS2Q4A3oAmHVq8gFwLnGTE00XG23slhEMIoHEuDoiKkReiKEiMZONCa+b5YvH8WbK5ls0ULbznB4hznMJJgzJDQYAE/FdVtjeNo4GHNaGhoa4BjwHCQWxSpwAyEfCsz7V9lZMY1t5oJk72N0l5Ewd685woQJWeytXBgcCQ57w0ukg3mAEgSc4ZFCaxOS4/XfP4PTbb7Q/vNxwhoeWsc2HPDaua0GrnVgAYBmElbbEkObfbcdHiuhrSAS7CIcCT4pIwMkY46XHNbvm6TcNwkEGb0gE4xERG76aDtDHXWVBeCG3mw6ccsYqBhN6Kq2cbLikYLZoY9zWSAHGATMCdc44qOde3XAYyCYvCuI61ldK32dj7pduzG+JmDSCY1nOk/0rO+yYHvv0F4Bsvh0atFb2Ma4VldPsm+FYzh+DTFP3pOlSqbR7STMzJy5+WVVda2EGpF0AGdJrE86eas/hwRF8RQgmZ0Iwxg/Os0XScpYGZ7cCBl660OaR7BpXMihWhuyuukgggT8QJPkMZ6yS1zFPIq9M4qNq6A1xJDZgH4QdBpQckxHX1TloMyOuBVIZlM46U+6pUjZnn79QkZYxQyWyYzkaFR8jESDWcD+2fJWWTycYzryx0K0lRZxIorLN7x8QjrNMWQZ5JHvAxw+X7KnLFja20PRRWGRr7qLfcY9FbYf2D/ycs7Rj1qiovM9taPgb5/Qrl2rzOJyUUWZ7F9L7Dwc/kFczP8Aq+jlFFm+61BGLf6h8wlfif7lFEUrxh6fQJLHE+X/AKtUUQmTtJxrX4Vd2g43Jmpc2Tmd4jHyoiou/FxrBsn/AE5zJAJzI7pxifOq2O/3Dn3kTwl1EFFpmNuxneAy3Kerlg7cYGWzwwBoFnIDaAHujWBmoos/0/xo2vZ2V3W1ZZk0FTetKnkOS8ptzzdFT4p9ZNUVFqexy/5bmuPeurgxkcP/ANGYLodksDntLgHG+Kmv+7xUUXHl6rE/g7R8X/cePSXUWTZN63tA6og0NRg7JRRZnqp1tr8I6yXNssB5n5lRRa+L/lU565q+yw9foFFF0oVn6qm6JwUUTAqc0Up1CpHx9ZKKLUSxvh60VTvi8vsootJQgoopP//Z">
                                <div class="slide-text">
                                    <h3 >Gunung Prau</h3>
                                    <p >Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quas soluta rem doloribus, facilis asperiores, in maiores aperiam eligendi nam quibusdam voluptatibus aspernatur voluptates quam necessitatibus voluptas sapiente officia ex beatae?</p>
                                </div>
                            </div>
                            <!-- Slide 2 -->
                            <div class="slide slide2 col-md-4" onclick="showSlide(1)"  data-background="https://sikidang.com/wp-content/uploads/Gunung-Prau-Wonosobo.jpg" data-text="Explore 2" >
                                <img class="inner" src="https://asset.kompas.com/crops/SJBld7b2CtJC5zJMlFbu1zKopZY=/1x319:1024x1001/750x500/data/photo/2022/09/04/6314d47545313.jpg">
                                <div class="slide-text">
                                    <h3 >Banda Neira</h3>
                                    <p >Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta blanditiis sint quas consectetur tempore natus ut enim asperiores. Iste quia praesentium quae? Animi pariatur rem perspiciatis porro eveniet id itaque..</p>     
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slider-controls">
                    <button class="carousel-control-prev ms-md-3" onclick="moveSlide('prev')">
                        <i class="fa-solid fa-arrow-left" ></i>
                    </button>
                    <button class="carousel-control-next" onclick="moveSlide('next')">
                        <i class="fa-solid fa-arrow-right" ></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
</body>
</html>
<?php
global $wpdb;
$id = $_GET['id'];
$table_smt_css = $wpdb->prefix . 'smt_style';
$data = $wpdb->get_row("SELECT * FROM $table_smt_css WHERE id_slider = $id ");
$css_data = json_decode($data->style_data, true);{
?>
<style>
     .sec {
        margin: 0;
        padding: 0;
        height: 100vh;
        overflow-x: hidden;
        overflow-y: hidden;
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
    }

    .slider-wrap {
    display: flex;
    overflow-x: hidden;
    }

    .slider-pannel {
        display: flex;
        transform: translateX(0);
        transition: transform 0.5s ease; 
        height: 430px;
        transition: transform 0.5s ease;
    }

    .slide {
        position: relative;
        overflow: hidden;
        width: 250px; 
        height: 350px; 
        margin: 0px;
        border: 1px solid rgba(179, 179, 179, 0.671);
        border-radius: 10px; 
        cursor: pointer;
        background: transparent;
        transition: transform 0.3s ease-in-out;
        transform: translateX(0);
    }

    .slide.active {
    transform: scale(1.05);
    }

    .slide:not(.active) {
        transform: scale(0.8);
    }

    .inner {
        width: 100%;
        height: 100%;
        object-fit: cover;
        position: absolute;
    }

    .indicator-dots {
        display: flex;
        flex-direction: column;
        align-items: center;
        position: absolute;
        left: 50px;
        top: 55%;
        transform: translateY(-50%);
    
    }

    .dot-wrapper {
        position: relative;
        margin-bottom: 100px; 
        z-index: 3;
    }

    .dot {
        width: 10px; 
        height: 10px; 
        background-color: <?php echo $css_data['dots_bg']; ?>;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease; 
    }

    .dot.active {
        background-color: <?php echo $css_data['dots_bg_active']; ?>;
        width: 25px; 
        height: 25px;
    }


    .dot:not(.active) .dot-number {
        display: none;
    }

    .dot-number {
        color:  <?php echo $css_data['dots_color']; ?>;
        font-size: 14px;
        font-weight: bold;
    }

    .dot-connector {
        position: absolute;
        width: 1px; 
        height: calc(100% - 100px);
        background-color: <?php echo $css_data['dots_line']; ?>;
        left: 50%; 
        top: 0; 
        transform: translateX(-50%);
    }

    .slider-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            
        }

    .carousel-control-prev{
        width: 35px;
        height: 35px;
        background-color:  <?php echo $css_data['control_bg']; ?>;
        border-radius: 50%;
        color:  <?php echo $css_data['control_color']; ?>;
        font-size: 24px;
        transition: opacity 0.1s ease-in-out;
        cursor: pointer;
        top:70%;
        left: 50%;
    }
    
    .carousel-control-next {
        width: 35px;
        height: 35px;
        background-color:  <?php echo $css_data['control_bg']; ?>;
        color:  <?php echo $css_data['control_color']; ?>;
        border-radius: 50%;
        font-size: 24px;
        transition: opacity 0.1s ease-in-out;
        cursor: pointer;
        top:70%;
        left: 55%;
    }


    .bg-container {
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    transition: background-image 0.5s ease;
    }
    .slide.active {
        background-image: none;
    }
    .slide_title{
        font-family:Futura MD BT;
        color:red;
    }
    .slide_desc{
        font-family:Berlin Sans FB;
        color:palevioletred;
    }
    .btn-custom{
        background-color: brown;
        padding: 7px;
        width: 100px;
    }
    .slide_title {
        transform: translateY(30px); 
        opacity: 0; 
        transition: transform 0.5s ease, opacity 0.5s ease; 
    }
    .slide_desc {
        transform: translateY(30px); 
        opacity: 0; 
        transition: transform 0.5s ease, opacity 0.5s ease; 
    }
    .btn-custom {
        transform: translateY(10px); 
        opacity: 1;
        transition: transform 0.5s ease, opacity 0.5s ease; 
    }
    .slide.active .slide_title,
    .slide.active .slide_desc,
    .slide.active .btn-custom {
        transform: translateY(0); 
        opacity: 1;
    }
    .text-slider {
        transition: opacity 0.2s ease, transform 0.2s ease;
    }
    .slide.active .text-slider {
        opacity: 1;
        transform: translateY(0);
    }
    

    @media (max-width: 767px) {
       .col-md-6 {
           margin-top: 20px;
       }

       .slider-pannel {
           height: 100%;
           align-items: center;
           margin: auto; 
       }

       .slide {
       width: 90%; 
       height: 100%;
       margin: 10px auto; 

       }
       .indicator-dots {
           flex-direction: row;
           margin-top: 35vw;
           margin-left: 35vw;
       }

       .dot-wrapper {
           margin-right: 10px; 
       }

       .dot-number {
           font-size: 10px; 
       }

       .dot-connector{
           display: none;
       }

       .carousel-control-prev{
           font-size: 18px;
           margin-left: -50px;
           margin-top: 10vw;
           
         
       }
       .carousel-control-next{
           margin-right: 200px;
           font-size: 18px;
           margin-top: 10vw;

       }
       .btn-custom{
            width:140px;
       }
       
   }
   @media (min-width: 768px) and (max-width: 1023px){
       .indicator-dots {
           left: 10px;
           transform: translateY(-65%);
          
       }
       .dot-wrapper {
           position: relative;
           margin-bottom: 80px; /* Jarak yang lebih besar antara nomor-nomor */
           z-index: 3;
       }
       .slider-pannel{
           margin-top: 280px ;
           display: flex;
       }
       .carousel-control-prev{
           font-size: 25px;
           margin-top: -10%;
       }
       .carousel-control-next{
           margin-left: 30px;
           display: flex;
           font-size: 25px;
           margin-top: -10%;
       }
   }
    .title_slide {
        font-family: <?php echo $css_data['title_fam']; ?>;
        color: <?php echo $css_data['title_color']; ?>;
    }

    .desc_slide {
        font-family: <?php echo $css_data['desc_fam']; ?>;
        color: <?php echo $css_data['desc_color']; ?>;
    }

    .btn-custom {
        font-family: <?php echo $css_data['btn_fam']; ?>;
        color: <?php echo $css_data['btn_color']; ?>;
        background-color: <?php echo $css_data['btn_bg']; ?>;
        border: none;
        padding: 7px;
        border-radius: 10px;
    }

    .btn-custom:hover {
        color: <?php echo $css_data['btn_color_hvr']; ?>;
        background-color: <?php echo $css_data['btn_bg_hvr']; ?>;
    }

</style>

<script>
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide');
    const bgContainer = document.querySelector('.bg-container');

    function showSlide(index) {
    if (index >= 0 && index < slides.length) {
        slides[currentSlide].classList.remove('active');
        slides[index].classList.add('active');
        const backgroundURL = slides[index].getAttribute('data-background');
        bgContainer.style.backgroundImage = `url('${backgroundURL}')`;
        currentSlide = index;

        const slideText = slides[index].querySelector('.slide-text');
        const title = slideText.querySelector('h3').textContent;
        const description = slideText.querySelector('p').textContent;

        const textSlider = document.querySelector('.text-slider');
        const buttonText = slides[index].getAttribute('data-text');
        const btnCustom = document.querySelector('.btn-custom');
        btnCustom.textContent = buttonText;
        // Apply sliding and fading animation
        textSlider.querySelector('<?php echo $css_data['title_size']; ?>').style.transform = 'translateY(-10px)';
        textSlider.querySelector('p').style.transform = 'translateY(-10px)';
        textSlider.querySelector('.btn-custom').style.transform = 'translateY(-5px)';
        textSlider.style.opacity = 0;

        setTimeout(() => {
            textSlider.querySelector('<?php echo $css_data['title_size']; ?>').textContent = title;
            textSlider.querySelector('p').textContent = description;
            textSlider.querySelector('<?php echo $css_data['title_size']; ?>').style.transform = 'translateY(0)';
            textSlider.querySelector('p').style.transform = 'translateY(0)';
            textSlider.querySelector('.btn-custom').style.transform = 'translateY(0)';
            textSlider.style.opacity = 1;
        }, 300); // Adjust the duration as needed

        const slideWidth = slides[0].offsetWidth; // Lebar slide
        const shift = -slideWidth * index; // Pergeseran

        const sliderPanel = document.querySelector('.slider-pannel');
        sliderPanel.style.transform = `translateX(${shift}px)`;

        // Mengatur status aktif atau tidak aktif pada indikator dot
        const dots = document.querySelectorAll('.dot');
        dots.forEach((dot, dotIndex) => {
            if (dotIndex === index) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
        updateIndicatorDots();
        updateSlideEffects();
    }}
function moveSlide(direction) {
    if (direction === 'prev') {
        const prevIndex = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(prevIndex);
    } else if (direction === 'next') {
        const nextIndex = (currentSlide + 1) % slides.length;
        showSlide(nextIndex);
    }
}
function updateIndicatorDots() {
    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, dotIndex) => {
        if (dotIndex === currentSlide) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

function updateSlideEffects() {
    const activeSlide = slides[currentSlide];
    const inactiveSlides = Array.from(slides).filter((slide, index) => index !== currentSlide);
    
    // Mengatur efek pada slide aktif
    activeSlide.style.transform = 'scale(1)';
    
    // Mengatur efek pada slide yang tidak aktif
    inactiveSlides.forEach(slide => {
        slide.style.transform = 'scale(0.8)';
    });
}

    function prevSlide() {
        const prevIndex = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(prevIndex);
    }

    function nextSlide() {
        const nextIndex = (currentSlide + 1) % slides.length;
        showSlide(nextIndex);
    }

    showSlide(currentSlide);
</script>

<?php
}
?>